import './page-util.scss';

function PageContentWrapper(props) {
	return <div className='wrapper'></div>;
}

export default PageContentWrapper;
