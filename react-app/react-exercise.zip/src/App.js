import NavBar from './components/page/util/NavBar';

export default function App() {
	return <NavBar />;
}
